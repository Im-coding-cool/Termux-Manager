ROOT_PSTH = '/home/chen/termux-manager/'

class ROOT_PATH:
    def __init__(self) -> None:
        self.ROOT_PATH = '/home/chen/termux-manager/'

# PATH = ROOT_PATH()
