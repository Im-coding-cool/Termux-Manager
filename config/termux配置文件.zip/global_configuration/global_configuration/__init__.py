ROOT_PSTH = '/data/data/com.termux/files/home/termux-manager/'

class ROOT_PATH:
    def __init__(self) -> None:
        self.ROOT_PATH = '/data/data/com.termux/files/home/termux-manager/'