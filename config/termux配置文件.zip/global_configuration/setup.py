from setuptools import setup
setup(name='global_configuration',
      version='0.0.1',
      description='用于获取全局配置',
      url='http://github.com/tongling/clinicaltrial',
      author='陈旺',
      author_email='1703214369@qq.com',
      license='MIT',
      packages=['global_configuration'],
      zip_safe=False)